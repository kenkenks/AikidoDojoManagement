# REFERENCES｜REQ-001

## 同梱
- `docs/ARCH-DRAFT_ATTENDANCE_DOMAIN_MODEL_20261021.md`：業務概念（現時点の設計基準）

## リポジトリ内の参照先（同梱なし）
- `web/qr/paper_attendance_scope.js`
- `web/qr/paper_attendance_review.js`
- `schema/Attendance.yml`
- `shared/DAO_Definitions.js`
- `docs/Architecture/ARCH-DRAFT_TRAINING_SCHEDULE_20261021.md`

その他の出席Core、Firestore保存、審査集計の関連箇所は調査で特定する。参照先の実在・内容は依頼実行時に確認すること。
